A Pen created at CodePen.io. You can find this one at http://codepen.io/THEORLAN2/pen/Kaewmw.

 Cusmont select, designed to change the typical style of the select in browsers, using js to display the list when it clicks, and scss, to give it style. The  Attribute selected work good, test it.  - Update - I added the select android style .
:)
